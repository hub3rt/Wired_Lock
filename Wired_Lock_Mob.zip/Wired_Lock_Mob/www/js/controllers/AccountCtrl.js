angular.module('starter.controllers.account', [])
.controller('AccountCtrl', function($scope) {
	
});