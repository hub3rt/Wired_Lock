angular.module('starter.controllers.dashboard', [])
.controller('DashboardCtrl', function($scope) {


	
	$scope.loginConnection = function(){
		console.log('toto');
		var login = $scope.login;
		console.log('login = ' +  $scope.login);
		if(login =='a'){
			$scope.test= 'ookkkk';
		}else{
			$scope.test = 'ko';
		}
		
	};


	$scope.logout = function(login,password){

		console.log('logout');
	};

	$scope.register = function(login,password){

		console.log('register');
	};
	
});