angular.module('starter.controllers.home', [])
.controller('HomeCtrl', function($scope) {
	
});